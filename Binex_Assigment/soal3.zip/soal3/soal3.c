#include <stdio.h>
#include <stdlib.h>

#define SECRET_CODE 0xDEADBEEF
int vault_state = 0;

void backdoor() {
    if (vault_state == SECRET_CODE) {
        char flag[64];
        FILE *f = fopen("flag.txt", "r");
        if (!f) {
            printf("Flag file missing!\n");
            exit(1);
        }
        fgets(flag, sizeof(flag), f);
        printf("Flag: %s\n", flag);
        fclose(f);
    } else {
        printf("Vault security protocol active!\n");
    }
}

void configure_vault() {
    vault_state = SECRET_CODE;
}

void vuln() {
    char buffer[32];
    printf("Enter configuration payload: ");
    fgets(buffer, 256, stdin);
}

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    vuln();
    printf("Configuration applied.\n");
    return 0;
}